package com.example.examen.services;

public class ExamService {

}
