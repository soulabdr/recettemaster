package com.example.examen.models;

import jakarta.persistence.Entity;

@Entity
public class ExamAdministrator extends User {
    // Additional properties and methods specific to Exam Administrator
}