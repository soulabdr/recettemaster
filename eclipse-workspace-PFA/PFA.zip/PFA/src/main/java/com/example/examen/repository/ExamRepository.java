package com.example.examen.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.examen.models.Exam;

public interface ExamRepository extends CrudRepository<Exam, Long> {
    // Additional methods if needed
}