package com.example.examen.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.examen.models.Course;

public interface CourseRepository extends CrudRepository<Course, Long> {
    // Additional methods if needed
}