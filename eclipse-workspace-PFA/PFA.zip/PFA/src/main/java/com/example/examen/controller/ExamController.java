package com.example.examen.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.examen.repository.ExamRepository;

@RestController
@RequestMapping("/exams")
public class ExamController {

    private final ExamRepository examRepository;

    @Autowired
    public ExamController(ExamRepository examRepository) {
        this.examRepository = examRepository;
    }

	public ExamRepository getExamRepository() {
		return examRepository;
	}

   
}
