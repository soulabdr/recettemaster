package com.example.examen.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.examen.models.Room;

public interface RoomRepository extends CrudRepository<Room, Long> {
    // Additional methods if needed
}
