package com.example.examen.models;

import jakarta.persistence.Entity;

@Entity
public class Student extends User {
    // Additional properties and methods specific to Student
}