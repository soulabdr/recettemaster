package com.example.examen.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.examen.models.Department;

public interface DepartmentRepository extends CrudRepository<Department, Long> {
    // Additional methods if needed
}